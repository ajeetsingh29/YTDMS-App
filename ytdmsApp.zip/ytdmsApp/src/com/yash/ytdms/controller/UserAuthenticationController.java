package com.yash.ytdms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdms.domain.User;
import com.yash.ytdms.service.UserService;
import com.yash.ytdms.serviceimpl.UserServiceImpl;

/**
 * Servlet implementation class UserAuthenticationController
 */
@WebServlet("/UserAuthenticationController")
public class UserAuthenticationController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	UserService userService;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserAuthenticationController() {
		super();
		userService = new UserServiceImpl();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		User loggedInUser = new User();
		loggedInUser = userService.authenthicateUser(request.getParameter("loginId"), request.getParameter("password"));
//		System.out.println(loggedInUser.getName()); for checking 
		if (loggedInUser != null) {
			HttpSession session =request.getSession();
			session.setAttribute("loggedInUserId", loggedInUser.getId());
			session.setAttribute("loggedInUserRole", loggedInUser.getRole());
			session.setAttribute("loggedInUser", loggedInUser);
			response.sendRedirect("trainer_dashboard.jsp");
		} else {
			response.sendRedirect("login.jsp?errmsg=invalid username or password");
		}
	}
}
