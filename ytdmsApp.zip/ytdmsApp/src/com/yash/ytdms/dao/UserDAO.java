package com.yash.ytdms.dao;


import java.util.List;
import com.yash.ytdms.domain.User;

/**
 * this component is used to declare all the crud operation
 * such as - save, update, list, delete 
 * @author samay.jain
 *
 */
public interface UserDAO {

	/**
	 * this method is used to save a new user in the database
	 * @param user which is to be entered in the database
	 */ 
	void save(User user);
	
	/**
	 * used to get the list of all users in the database
	 * @return list of users
	 */
	List<User> finalAll();
	
	/**
	 * this method is used to update the user 
	 * @param user which needed to be updated
	 */
	void update(User user);
	
	/**
	 * this method is used to delete a user from database
	 * @param user which is going to be remove from database
	 */
	void delete(User user);
}
