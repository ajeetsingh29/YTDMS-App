package com.yash.ytdms.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * this component will provide the utility of services of DB like Open, connect,
 *  PreparedStatement 
 * @author samay.jain
 *
 */
public class DbUtils {

	static private String driverClassName = "com.mysql.jdbc.Driver";
	private String url= "jdbc:mysql://localhost/ytdmsdb";
	private String username= "root";
	private String password="root";
	private Connection con;
	private PreparedStatement pstmt;
	
	/**
	 * this static block is used to get class for Db connectivity
	 */
	static {
		Class c;
		try {
			c = Class.forName(driverClassName);
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * this method is used to make connection with database 
	 * @return connection establish between database
	 */
	private  Connection connect() {
		try {
			con = DriverManager.getConnection(url, username, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	/**
	 * this method is used to create a prepared Statement for data manipulation
	 * @param sql query to be executed 
	 * @return prepared Statement
	 */
	public  PreparedStatement preparedStatement(String sql) {
		try {
			pstmt = connect().prepareStatement(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return pstmt;
		
	}
}

