package com.yash.ytdms.util;

public class StringUtils {
	public static boolean verifyString(String description, int length) {
		if( description.length()>length) {
			return true;
		}
		else {
			return false;
		}
		
	}


}
