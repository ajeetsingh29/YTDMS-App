package com.yash.ytdms.service;

import java.util.List;

import com.yash.ytdms.domain.Category;

public interface CategoryService {
	String STATUS_BLOCKED="2";
	String STATUS_ACTIVE="1";
	List <Category> findAll();
	void addCategory(Category category);
	void removeCategory(String categoryId);
	void editCategory(String categoryId);
	Category getCategoryElement(String categoryId);

}
