package com.yash.ytdms.serviceimpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.daoImpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.util.DbUtils;

public class CategoryServiceImpl extends DbUtils implements CategoryService  {
	CategoryDAO categoryDAO = null;
	public CategoryServiceImpl() {
		categoryDAO= new CategoryDAOImpl();
	}

	@Override
	public List<Category> findAll() {
		
		
		return categoryDAO.findlAll();
			
	}

	@Override
	public void addCategory(Category category) {
		category.setStatus(STATUS_ACTIVE);
		categoryDAO.save(category);
		
	}



	@Override
	public void removeCategory(String categoryId) {
		// TODO Auto-generated method stub
		categoryDAO.removeCategory(categoryId);
		
	}

	@Override
	public void editCategory(String categoryId) {
		categoryDAO.editCategory(categoryId);
		
	}

	@Override
	public Category getCategoryElement(String categoryId) {
		 Category category=categoryDAO.getCategoryElement(categoryId);
		return category;
	}
	

}
