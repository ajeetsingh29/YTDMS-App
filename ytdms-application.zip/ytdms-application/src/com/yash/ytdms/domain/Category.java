package com.yash.ytdms.domain;

public class Category {
	/**
	 * this the unique id of the user
	 */
	private int id;
	/**
	 * this is the userId of the user
	 */
	private int userId;

	/**
	 * this is the name of the user
	 */
	private String name;
	/**
	 * this the status of the user
	 */
	private String status;
	/**
	 * this is the description of the user
	 */
	private String description;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	

}
