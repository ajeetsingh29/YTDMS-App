package com.yash.ytdms.daoImpl;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.yash.ytdms.dao.UserDAO;
import com.yash.ytdms.domain.User;
import com.yash.ytdms.util.DbUtils;

/**
 * this component is used to implement all the crud operation
 * @author samay.jain
 *
 */
public class UserDAOImpl extends DbUtils implements UserDAO {

	@Override
	public void save(User user) {
		String sql = "INSERT into users(name,email,loginId,password,role,status) value (?,?,?,?,?,?)";
		PreparedStatement pstmt = preparedStatement(sql);
		try {
			pstmt.setString(1, user.getName());
			pstmt.setString(2, user.getEmail());
			pstmt.setString(3, user.getLoginId());
			pstmt.setString(4, user.getName());
			pstmt.setInt(5, user.getRole());
			pstmt.setInt(6, user.getStauts());
			pstmt.execute();
		
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	

	@Override
	public void update(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public void delete(User user) {
		// TODO Auto-generated method stub

	}

	@Override
	public List<User> findlAll() {
		// TODO Auto-generated method stub
		return null;
	}

}
