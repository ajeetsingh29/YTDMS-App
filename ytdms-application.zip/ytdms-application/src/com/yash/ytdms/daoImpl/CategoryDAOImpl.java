package com.yash.ytdms.daoImpl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import com.yash.ytdms.dao.CategoryDAO;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.domain.User;
import com.yash.ytdms.util.DbUtils;

public class CategoryDAOImpl extends DbUtils implements CategoryDAO {

	@Override
	public List<Category> findlAll() {
		List<Category> categories =new ArrayList();
		String sql="select * from categories";
	    PreparedStatement pstmt = preparedStatement(sql);
	    try {
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()){
				Category category=new Category();
				category.setName(rs.getString("name"));
				category.setStatus(rs.getString("status"));
				category.setDescription(rs.getString("description"));
				category.setId(rs.getInt("id"));
				category.setUserId(rs.getInt("userId"));
				categories.add(category);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return categories;
	}

	@Override
	public void save(Category category) {
		String sql="insert into categories(name,description,userId,status) values(?,?,?,?)";
	    PreparedStatement pstmt = preparedStatement(sql);
	    try {
			
			
			
			pstmt.setString(1, category.getName());
			pstmt.setString(2, category.getDescription());
			pstmt.setInt(3, category.getUserId());
			pstmt.setString(4, category.getStatus());
			pstmt.execute();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public void removeCategory(String categoryId) {
		String sql="delete from categories where id =" + categoryId;
		 PreparedStatement pstmt = preparedStatement(sql);
		 try {
			pstmt.execute();
			System.out.println(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
//	String sql="update categories set name= ?,description= ?,userId= ?,status= ? where id = ?";
	@Override
	public void editCategory(String categoryId) {
	    
		
	}
	public void editCategory(Category category) {
		String sql=" update categories set name=? , description = ? where id=" + category.getId();
	    PreparedStatement pstmt = preparedStatement(sql);
	    try {
			pstmt.setString(1, category.getName());
			pstmt.setString(2, category.getDescription());
			pstmt.execute();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	    
		
	

	@Override
	public Category getCategoryElement(String categoryId) {
		Category category=new Category();
		
		String sql="select * from categories where id="+categoryId;
	    PreparedStatement pstmt = preparedStatement(sql);
	    try {
			ResultSet rs=pstmt.executeQuery();
			
			while(rs.next()){
				
				category.setName(rs.getString("name"));
				category.setStatus(rs.getString("status"));
				category.setDescription(rs.getString("description"));
				category.setId(rs.getInt("id"));
				category.setUserId(rs.getInt("userId"));
				
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return category;
	}

}
