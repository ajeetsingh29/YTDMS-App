package com.yash.ytdms.dao;

import java.util.List;

import com.yash.ytdms.domain.Category;
import com.yash.ytdms.domain.User;

public interface CategoryDAO {
	List<Category> findlAll();
	void save(Category category);
	void removeCategory(String categoryId);
	void editCategory(String categoryId);
	// 	Category getCategoryElement(String categoryId);
     public void editCategory(Category category);
	
	/**
	 * this method is used to update the user 
	 * @param user which needed to be updated
	 */

}
