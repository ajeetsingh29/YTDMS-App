package com.yash.ytdms.test;

import com.yash.ytdms.daoImpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;

public class testingEdit {

	public static void main(String[] args) {
		CategoryDAOImpl categoryDAOImpl = new CategoryDAOImpl();
		Category category = new Category();
		category.setName("java 8");
		category.setDescription("sjghfd");
		category.setId(5);
		categoryDAOImpl.editCategory(category);
		System.out.println("done");

	}

}
