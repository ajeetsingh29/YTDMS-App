package com.yash.ytdms.test;


import com.yash.ytdms.daoImpl.UserDAOImpl;
import com.yash.ytdms.domain.User;
import com.yash.ytdms.util.DbUtils;

/**
 * use for testing data base connectivity and its operation 
 * @author samay.jain
 *
 */
public class DbUtilConnectionTest extends DbUtils {
	 public static void main(String[] args) {
		User user =new User();
		user.setName("samay");
		user.setEmail("samay@yash.com");
		user.setLoginId("samay1");
		user.setPassword("samay123");
		UserDAOImpl daoImpl = new UserDAOImpl();
		daoImpl.save(user);
		
		System.out.println("done");
	}


}
