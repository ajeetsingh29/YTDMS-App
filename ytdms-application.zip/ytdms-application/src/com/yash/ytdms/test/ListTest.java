package com.yash.ytdms.test;

import java.util.List;

import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;

public class ListTest {

	public static void main(String[] args) {
		CategoryService categoryService=new CategoryServiceImpl();
		List<Category> categories=categoryService.findAll();
		System.out.println(categories.size());
		for (Category category : categories) {
			System.out.println(category);
		}
	}

}
