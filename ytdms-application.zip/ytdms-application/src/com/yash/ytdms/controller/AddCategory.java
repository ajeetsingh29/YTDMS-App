package com.yash.ytdms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class AddCategory
 */
@WebServlet("/AddCategory")
public class AddCategory extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CategoryService categoryService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCategory() {
        super();
        categoryService=new CategoryServiceImpl();
       
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Category category=new Category();
		HttpSession session =request.getSession();
		int loggedInUserId=(int)session.getAttribute("loggedInUserId");
		category.setName(request.getParameter("name"));
		category.setDescription(request.getParameter("description"));
		category.setUserId(loggedInUserId);
		categoryService.addCategory(category);
		getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request,response );
		
		
		
	}

}
