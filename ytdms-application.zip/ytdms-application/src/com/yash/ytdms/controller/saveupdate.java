package com.yash.ytdms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.yash.ytdms.daoImpl.CategoryDAOImpl;
import com.yash.ytdms.domain.Category;
import com.yash.ytdms.service.CategoryService;
import com.yash.ytdms.serviceimpl.CategoryServiceImpl;

/**
 * Servlet implementation class AddCategory
 */
@WebServlet("/saveupdate")
public class saveupdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private CategoryService categoryService;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public saveupdate() {
        super();
        categoryService=new CategoryServiceImpl();
       
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Category category=new Category();
		HttpSession session =request.getSession();
		category.setName(request.getParameter("name"));
		Category  category2=(Category)session.getAttribute("UpdateUser");
		category.setDescription(request.getParameter("description"));
		category.setId(category2.getId());
		
		categoryService.addCategory(category);
		CategoryDAOImpl categoryDAOImpl=new CategoryDAOImpl();
		categoryDAOImpl.editCategory(category);
		getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request,response );
		
	
		
		//getServletContext().getRequestDispatcher("/CategoryPreparationController").forward(request,response );
		//getServletContext().getRequestDispatcher("/saveupdate").forward(request,response );
		
		
	}

}
