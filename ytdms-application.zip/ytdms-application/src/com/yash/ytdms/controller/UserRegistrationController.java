package com.yash.ytdms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.yash.ytdms.daoImpl.UserDAOImpl;
import com.yash.ytdms.domain.User;
import com.yash.ytdms.execption.UserException;
import com.yash.ytdms.serviceimpl.UserServiceImpl;

/**
 * this component is used to call the service method of the User registration 
 * Servlet implementation class UserRegistrerationController
 */
@WebServlet("/UserRegistrerationController")
public class UserRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private UserServiceImpl userServiceImpl;   
    
    
    public UserRegistrationController() {
        super();
        userServiceImpl =new UserServiceImpl();
    }

	/**
	 * this method is used for taking data from UI and redirect on view
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO user input
		User user =new User();
		
		user.setName(request.getParameter("name"));
		user.setEmail(request.getParameter("email"));
		user.setLoginId(request.getParameter("loginId"));
		user.setPassword(request.getParameter("password"));
		
		try {
			userServiceImpl.register(user);
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		System.out.println("okay");
		response.sendRedirect("login.jsp?msg=User registered sucessfully");
		//response.sendRedirect("login.jsp");
	}

}
