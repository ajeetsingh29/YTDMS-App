package com.yash.ytdms.dao;

import com.yash.ytdms.domain.Document;
/**
 * This component inserts the data in the database
 * @author ajeet.chouhan
 *
 */
public interface DocumentDAO {
	/**
	 * The insert method takes a document parameter and then saves the document 
	 * @param document
	 */
	
	void insert(Document document);
	
}
