package com.yash.ytdms.domain;
/**
 * This Document domain works as data traveler from layer to layer
 * This will represent the user document record in database
 * @author ajeet.chouhan
 *
 */

public class Document {
	/**
	 * This is the unique id of the Document
	 * This will be PK
	 */
	private int id;
	/**
	 * This sectionIid is the unique  id for corresponding session.
	 */
	private int sectionId;
	/**
	 * This category Id is the unique  id for corresponding category.
	 */
	private int categoryId;
	/**
	 * This  userId is the unique  id for corresponding category.
	 */
	private int userId;
	/**
	 * This  title is the title for corresponding document.
	 */
	private String title;
	/**
	 * This status field will store the status to enable and disable the file.
	 * 1-->enable
	 * 0-->disable
	 */
	private int status;
	/**
	 * This hide will store the information regarding the hide and unhiding the document
	 * 1-->hide
	 * 0-->unhidden
	 */
	private int hide;
	/**
	 * This content field will store the content of the file
	 */
	private String content;
	/**
	 * getter method for ID
	 * @return
	 */

	public int getId() {
		return id;
	}
	/**
	 * setter method for ID
	 * @return
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * getter method for sectionId
	 * @return
	 */
	public int getSectionId() {
		return sectionId;
	}
	/**
	 * setter method for sectionId 
	 * @return
	 */
	public void setSectionId(int sectionId) {
		this.sectionId = sectionId;
	}
	/**
	 * getter method for categoryId
	 * @return
	 */
	public int getCategoryId() {
		return categoryId;
	}
	/**
	 * setter method for categoryId
	 * @return
	 */
	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}
	/**
	 * getter method for userId
	 * @return
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * setter method for userId
	 * @return
	 */
	
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * getter method for 
	 * @return
	 */
	public String getTitle() {
		return title;
	}
	/**
	 * setter method for userId
	 * @return
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	/**
	 * getter method for 
	 * @return
	 */
	public int getStatus() {
		return status;
	}
	/**
	 * setter method for userId
	 * @return
	 */
	public void setStatus(int status) {
		this.status = status;
	}
	/**
	 * getter method for 
	 * @return
	 */
	public int getHide() {
		return hide;
	}
	/**
	 * setter method for hide
	 * @return
	 */
	public void setHide(int hide) {
		this.hide = hide;
	}
	/**
	 * getter method for content
	 * @return
	 */
	public String getContent() {
		return content;
	}
	/**
	 * setter method for content
	 * @return
	 */
	public void setContent(String content) {
		this.content = content;
	}

}
