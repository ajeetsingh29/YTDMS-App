package com.yash.ytdms.daoimpl;

import java.sql.PreparedStatement;
/**
 * This is the implementation for the DocumentDAO
 */
import java.sql.SQLException;

import com.yash.ytdms.dao.DocumentDAO;
import com.yash.ytdms.domain.Document;

import com.yash.ytdms.util.JNDIUtil;

public class DocumentDAOImpl extends JNDIUtil implements DocumentDAO {

	@Override
	public void insert(Document document) {
		String sql = "INSERT INTO documents (userId, categoryId, sectionId, content, STATUS,hide, title) VALUES(?,?,?,?,?,?,?)";
		PreparedStatement pstmt =preparedStatement(sql);
		try {
			pstmt.setInt(1, document.getId());
			pstmt.setInt(2,  document.getCategoryId());
			pstmt.setInt(3, document.getSectionId());
			pstmt.setString(4, document.getContent());
			pstmt.setInt(5, document.getStatus());
			pstmt.setInt(6, document.getHide());
			pstmt.setString(7, document.getTitle());
			pstmt.execute();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
