package com.yash.ytdms.serviceimpl;

import com.yash.ytdms.dao.DocumentDAO;
import com.yash.ytdms.daoimpl.DocumentDAOImpl;
import com.yash.ytdms.domain.Document;
import com.yash.ytdms.service.DocumentService;

public class DocumentServiceImpl implements DocumentService {
	 DocumentDAO documentDAO = new DocumentDAOImpl();

	@Override
	public void save(Document document) {
		documentDAO.insert(document);
		
	}



	
}
