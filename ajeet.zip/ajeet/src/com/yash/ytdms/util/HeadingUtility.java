package com.yash.ytdms.util;
/**
 * Utility method for providing title heading in the document.
 * @author ajeet.chouhan
 *
 */
public class HeadingUtility {
	/**
	 * This method adds heading in the document title
	 * @param title
	 * @param content
	 * @return the appended heading
	 */
	public static String setTitleHeading(String title, String content) {
		StringBuilder contents=new StringBuilder();
		contents.append("<h3>");
		contents.append(title);
		contents.append("</h3>");
		contents.append(content);
		
		return contents.toString();
	}

}
