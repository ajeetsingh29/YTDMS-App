package com.yash.ytdms.service;

import com.yash.ytdms.domain.Document;
import com.yash.ytdms.domain.Test;
import com.yash.ytdms.exception.TestException;

public interface DocumentService {
	void save(Document document);




}
