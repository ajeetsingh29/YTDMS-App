package com.yash.ytdms.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.yash.ytdms.dao.DocumentDAO;
import com.yash.ytdms.daoimpl.DocumentDAOImpl;
import com.yash.ytdms.domain.Document;
import com.yash.ytdms.service.DocumentService;
import com.yash.ytdms.serviceimpl.DocumentServiceImpl;
import com.yash.ytdms.util.HeadingUtility;

/**
 * Servlet implementation class AddDocumentController
 */
@WebServlet("/AddDocumentController")
public class AddDocumentController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private DocumentService documentService = null;
	static final Logger LOGGER = Logger.getLogger(AddDocumentController.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddDocumentController() {
		super();
		documentService = new DocumentServiceImpl();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Document document = new Document();
		document.setTitle(request.getParameter("title"));
		

		document.setContent(request.getParameter("content"));
		// String contents =
		// HeadingUtility.setTitleheading(request.getParameter("title"),
		// request.getParameter("content"));
		//
		// document.setContent(contents);
		try {
			documentService.save(document);
			LOGGER.info("Document Added successully");
		} catch (Exception e) {
			LOGGER.info("Document not created");
		}

	}

}
